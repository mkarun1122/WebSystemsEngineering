<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form fields are not empty
    if (isset($_POST['name']) && isset($_POST['email'])) {
        // Retrieve data from text boxes
        $name = $_POST['name'];
        $email = $_POST['email'];

        // Output the data
        echo "<h1>Your Details</h1>";
        echo "Name: " . htmlspecialchars($name) . "<br>";
        echo "Email: " . htmlspecialchars($email) . "<br>";
    } else {
        echo "Please fill out the form.";
    }
}
?>