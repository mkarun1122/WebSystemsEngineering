<!DOCTYPE html>
<html>
<body>

<?php


echo "Welcome Php!!!";
// Arrays in PHP
// An array in PHP is a variable that can store multiple values. Arrays can be indexed (using integers) or associative (using named keys).

$fruits = array("Apple", "Banana", "Cherry");
echo $fruits[1]; // Output: Banana


?>

</body>
</html>
