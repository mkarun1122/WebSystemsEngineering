<!DOCTYPE html>
<html>
<body>

<?php


echo "Welcome Php!!!";

$fruits = array("Apple", "Banana", "Cherry");
echo $fruits[1]; // Output: Banana


?>

</body>
</html>
