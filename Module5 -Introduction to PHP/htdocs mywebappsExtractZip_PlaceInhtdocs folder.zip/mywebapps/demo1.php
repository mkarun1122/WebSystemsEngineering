<!DOCTYPE html>
<html>
<body>

<?php


echo "Welcome Php!!!";
$x = 5;
var_dump($x);
?>

</body>
</html>
